const products = [
  {
    name: 'Premium Dog Food - 10kg Bag',
    image: '/uploads/dog_food.jpg',
    description: 'High-quality dog food with essential nutrients for optimal health and energy. Suitable for all breeds and sizes of dogs.',
    category: 'Dog Food',
    price: 5999,
    countInStock: 15,
    rating: 4.8,
    numReviews: 85
  },
  {
    name: 'Interactive Cat Toy Set',
    image: '/uploads/cat_toys.jpg',
    description: 'A variety pack of interactive toys to keep your cat entertained and engaged. Includes balls, mice, and teaser wands.',
    category: 'Cat Toys',
    price: 2999,
    countInStock: 20,
    rating: 4.5,
    numReviews: 72
  },
  {
    name: 'Tropical Fish Aquarium Starter Kit',
    image: '/uploads/fish_aquarium.jpg',
    description: 'Complete aquarium kit for tropical fish enthusiasts. Includes tank, filter, heater, LED lighting, and water conditioner.',
    category: 'Fish Supplies',
    price: 8999,
    countInStock: 10,
    rating: 4.7,
    numReviews: 63
  },
  {
    name: 'Dog Grooming Brush',
    image: '/uploads/dog_brush.jpg',
    description: 'Gentle yet effective grooming brush for removing loose hair and preventing mats. Suitable for all coat types.',
    category: 'Dog Grooming',
    price: 1499,
    countInStock: 25,
    rating: 4.6,
    numReviews: 68
  },
  {
    name: 'Cat Scratching Post',
    image: '/uploads/cat_scratcher.jpg',
    description: 'Durable scratching post made of sisal rope and plush fabric. Provides a healthy outlet for your cat\'s scratching instincts.',
    category: 'Cat Furniture',
    price: 2499,
    countInStock: 18,
    rating: 4.4,
    numReviews: 54
  },
  {
    name: 'Tropical Fish Food Flakes',
    image: '/uploads/fish_food.jpg',
    description: 'Nutritious fish food flakes enriched with vitamins and minerals for vibrant tropical fish colors and overall health.',
    category: 'Fish Food',
    price: 999,
    countInStock: 30,
    rating: 4.9,
    numReviews: 78
  },
  {
    name: 'Dog Chew Toys Variety Pack',
    image: '/uploads/dog_chew_toys.jpg',
    description: 'Assorted pack of durable chew toys to satisfy your dog\'s natural urge to chew. Helps promote dental health and reduce boredom.',
    category: 'Dog Toys',
    price: 1999,
    countInStock: 22,
    rating: 4.7,
    numReviews: 60
  },
  {
    name: 'Interactive Cat Feeder Puzzle',
    image: '/uploads/cat_feeder_puzzle.jpg',
    description: 'Innovative feeder puzzle designed to stimulate your cat\'s mind during mealtime. Encourages slower eating and reduces digestive issues.',
    category: 'Cat Feeding Accessories',
    price: 1499,
    countInStock: 17,
    rating: 4.5,
    numReviews: 46
  },
  {
    name: 'TetraColor Tropical Fish Granules',
    image: '/uploads/fish_granules.jpg',
    description: 'Highly nutritious granules specially formulated to enhance the natural colors of tropical fish. Supports healthy growth and vitality.',
    category: 'Fish Food',
    price: 1299,
    countInStock: 28,
    rating: 4.6,
    numReviews: 55
  },
  {
    name: 'Dog Bed with Removable Cover',
    image: '/uploads/dog_bed.jpg',
    description: 'Comfortable dog bed with a soft plush surface and a removable cover for easy cleaning. Provides orthopedic support for a restful sleep.',
    category: 'Dog Beds',
    price: 3499,
    countInStock: 12,
    rating: 4.8,
    numReviews: 38
  },
  {
    name: 'Cat Litter Box with Scoop',
    image: '/uploads/cat_litter_box.jpg',
    description: 'Spacious litter box with a high-sided design to contain litter scatter. Includes a scoop for easy waste removal and cleaning.',
    category: 'Cat Litter Accessories',
    price: 2799,
    countInStock: 20,
    rating: 4.4,
    numReviews: 42
  },
  {
    name: 'Aquarium Plant Decoration Set',
    image: '/uploads/fish_plant_decoration.jpg',
    description: 'Set of artificial plants and ornaments to create a natural-looking underwater habitat in your aquarium. Safe for fish and easy to clean.',
    category: 'Fish Tank Decor',
    price: 1899,
    countInStock: 15,
    rating: 4.3,
    numReviews: 36
  }
];

export default products;
